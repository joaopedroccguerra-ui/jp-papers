# Pasta de ficheiros

Coloca aqui os PDFs (practice papers, mark schemes, notes).

Depois de adicionares um ficheiro, abre `assets/data.js` e acrescenta uma linha
na disciplina certa, por exemplo:

    { name: "Physics Paper 2 practice", type: "Paper", url: "files/physics-p2.pdf" }

O nome do ficheiro não deve ter espaços nem acentos.
